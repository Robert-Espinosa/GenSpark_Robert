import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
public class StudentManagementSystem {
    public static void main(String[] args) {
        //cleaner print method that is called statically
        printMenu();

        //Initalize our arrays to store Students and Courses, Becasue we need to store somewhere when initalized.
        ArrayList<Course> courses = new ArrayList<>();
        ArrayList<Student> students = new ArrayList<>();

        //Begin our scanner and scan until user enters -1 to quit
        Scanner in = new Scanner(System.in);
        String input;
        while (!(input = in.next()).equals("-1")) {
            //store what the user wants to do in menu
            int result = 0;

            try {
                result = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input Please enter a number from 1-12 or -1 to quit.");
            }
            //Used helper methods described below in order to call each functionallity of the gradebook
            if (result == 1) {
                addStudent(in,students);
            } else if (result == 2) {
                editStudent(in, students);
            } else if (result == 3) {
                removeStudent(in,students);
            } else if (result == 4) {
                viewStudent(in,students);
            } else if (result == 5) {
                addCourse(in,courses);
            } else if (result == 6) {
                editCourse(in, courses);
            } else if (result == 7) {
                deleteCourse(in,courses);
            } else if (result == 8) {
                displayStudent(in, courses);
            } else if (result == 9) {
                enrollStudent(in,students,courses);
            } else if (result == 10) {
                dropClass(in,students,courses);
            } else if (result == 11) {
                displayStudents(in,courses);
            } else if (result == 12) {
                displayCourses(in,students);
            } else {
                //tell them they need to enter number 1-12
                System.out.println("Error Number out of bounds, enter number between 1-12\n");
            }

            printToFile(students,courses);
            printMenu();
        }

    }
        public static void printMenu () {
            //a lot of print statements so decided to seperate it from the main
            System.out.println("Please select from the menu below the operation you want enter digit 1-12");
            System.out.println("1. Add new Student");
            System.out.println("2. Update Student using ID");
            System.out.println("3. Delete Student using ID");
            System.out.println("4. View Student using ID");
            System.out.println("----------------------");
            System.out.println("5. add new course");
            System.out.println("6. Update course title");
            System.out.println("7. Delete course by ID");
            System.out.println("8. view details of a course");
            System.out.println("----------------------");
            System.out.println("9. Enroll a Student into class");
            System.out.println("10. Withdraw Student from class");
            System.out.println("11. Display all courses Student is enrolled in");
            System.out.println("12. Display all student in a course using CourseID");

        }
        //goes through our array of students and finds the index of
        //this is extreemly helpful becasue of the -1 conditon and makes easy for other methods
        public static int indexOfStudent(ArrayList<Student>  students, String id){
            for(int i = 0; i<students.size();i++){
                if(students.get(i).getID().equals(id)){
                    return i;
                }
            }
            return -1;
        }
        //goes through our array of courses and finds the index of course based on id
        //again more so a helper method for the functions below
        public static int indexOfCourse(ArrayList<Course> courses, String courseID){
            for(int i = 0; i<courses.size();i++){
                if(courses.get(i).getCourseID().equals(courseID)){
                    return i;
                }
            }
            return -1;
        }

        //add student asks for ID NAME and DOB, then creates student obj and stores in our array
        public static void addStudent(Scanner in, ArrayList<Student> students){
            try {
                System.out.print("Enter student ID: ");
                String id = in.next();
                System.out.print("enter the Student name: ");
                String name = in.next();
                System.out.print("enter the Student DOB ");
                String age = in.next();
                Student s = new Student(id,name,age);
                students.add(s);
            } catch(InputMismatchException e){
                System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
            }
        }
        //edit student grabs the student ID and then asks for new name and DOB,
        //then it updates the characteristics and repalces them in our array
        public static void editStudent(Scanner in, ArrayList<Student> students){
            try {
                System.out.print("Enter student ID: ");
                String id = in.next();
                System.out.print("enter the new Student name: ");
                String name = in.next();
                System.out.print("enter the new Student DOB ");
                String DOB = in.next();
                int index = indexOfStudent(students,  id);
                if(index != -1) {
                    Student editedStudent = students.get(index);
                    editedStudent.setDOB(DOB);
                    editedStudent.setName(name);
                }else{
                    System.out.println("Error student not found");
                }


            } catch(InputMismatchException e){
                System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
            }

        }
        //remove student uses the index of to find the student in our array and the simply calls .remove
        public static void removeStudent(Scanner in, ArrayList<Student> students){
            try {
                System.out.print("Enter student ID to remove: ");
                String id = in.next();
                int index = indexOfStudent(students,  id);
                if(index != -1) {
                    students.remove(indexOfStudent(students, id));

                }else{
                    System.out.println("student does not exist");
                }
                System.out.println(students.size());
                System.out.println();

            } catch(InputMismatchException e){
                System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
            }
        }

        //take in a ID and then finds the index of student and procceds to print out the toString method for the student.
        public static void viewStudent(Scanner in, ArrayList<Student> students){
            try {
                System.out.print("Enter student ID to view: ");
                String id = in.next();
                int index = indexOfStudent(students,  id);
                if(index!=-1) {
                    System.out.println(students.get(index).toString());
                }else{
                    System.out.println("student does not exist");
                }
            } catch(InputMismatchException e){
                System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
            }
        }

        //takes all inital parameters that a course needs and then creates a new course obj and adds it to the array
        public static void addCourse(Scanner in, ArrayList<Course> courses){
            try {
                System.out.print("Enter courseID: ");
                String id = in.next();
                System.out.print("enter the title of course: ");
                String title = in.next();
                Course c = new Course(id, title);
                courses.add(c);
                System.out.println("success");
            } catch(InputMismatchException e){
                System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
            }
        }
        // takes in a course Id and then allows you to change the title of the course
        public static void editCourse(Scanner in, ArrayList<Course> courses){
            try {
                System.out.print("Enter courseID: ");
                String id = in.next();
                System.out.print("enter the NEW title of course: ");
                String title = in.next();
                int index = indexOfCourse(courses, id);
                if (index != -1){
                    courses.get(index).setTitle(title);
                }else{
                    System.out.println("Error course does not exist ");
                }
            } catch(InputMismatchException e){
                System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
            }
        }

        //if course does get deleted you still need to remove all of the students from course
        public static void deleteCourse(Scanner in, ArrayList<Course> courses){
            try {
                System.out.print("Enter courseID of the course to delete: ");
                String id = in.next();
                int index = indexOfCourse(courses,  id);
                if(index != -1) {
                    courses.remove(indexOfCourse(courses, id));
                    System.out.println("successfully deleted course");

                }else{
                    System.out.println("error course does not exist");
                }
            } catch(InputMismatchException e){
                System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
            }
        }
        //takes in course ID and then finds the course in the array and prints its to string method
        public static void displayStudent(Scanner in, ArrayList<Course> courses){
            try {
                System.out.print("Enter courseID of the course to view: ");
                String id = in.next();
                int index = indexOfCourse(courses,  id);
                if(index!= -1) {
                    System.out.println(courses.get(index).toString());
                }else{
                    System.out.println("error course does not exist ");
                }
            } catch(InputMismatchException e){
                System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
            }
        }
        //takes a student Id and CourseID and then accesses thoses course and student in our array
        // from there we can access the students courses and add the course and vise versa
        public static void enrollStudent(Scanner in, ArrayList<Student> student, ArrayList<Course> courses){
            try {
                System.out.print("Enter Student ID of the student you would like to enroll: ");
                String id = in.next();
                System.out.print("Enter the course ID of the course to enroll the student into: ");
                String courseID = in.next();

                int courseIndex = indexOfCourse(courses,  courseID);
                int studentIndex = indexOfStudent(student,  id);

                if(courseIndex != -1 && studentIndex!=-1) {
                    courses.get(courseIndex).addStudent(student.get(studentIndex));
                    student.get(studentIndex).addCourse(courses.get(courseIndex));
                    System.out.print("successful enroll");


                }else{
                    System.out.println("either course or student does not exist");
                }


            } catch(InputMismatchException e){
                System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
            }
        }

        //
        public static void dropClass(Scanner in, ArrayList<Student> student, ArrayList<Course> courses){
            try {
                System.out.print("Enter Student ID of the student you would like to drop: ");
                String id = in.next();
                System.out.print("Enter the course ID of the course to drop student from: ");
                String courseID = in.next();

                int courseIndex = indexOfCourse(courses,  courseID);
                int studentIndex = indexOfStudent(student,  id);

                if(courseIndex != -1 && studentIndex !=-1) {

                    courses.get(courseIndex).deleteStudent(student.get(studentIndex).getID());
                    student.get(studentIndex).deleteStudent(courses.get(courseIndex).getCourseID());

                }else{
                    System.out.println("Either student or course does not exist");
                }

            } catch(InputMismatchException e){
                System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
            }

        }

        //displays Students by getting the index of the student then getting the student courses and using my toString

        public static void displayStudents(Scanner in, ArrayList<Course> courses){
                try {
                    System.out.print("Enter courseID to get students: ");
                    String courseID = in.next();

                    int courseIndex = indexOfCourse(courses,  courseID);

                    if(courseIndex != -1) {
                       System.out.println(courses.get(courseIndex).getStudents().toString());
                    }else{
                        System.out.println("course does not exist");
                    }

                } catch(InputMismatchException e){
                    System.out.print("please enter an valid Integer, String, integer, and double to add student\n");
                }

            }
        //displays courses by getting the index of the student then getting the student courses and using my toString
        public static void displayCourses(Scanner in, ArrayList<Student> students){
            try {
                System.out.print("Enter studentID to get their courses: ");
                String studentID = in.next();

                int studentIndex = indexOfStudent(students,  studentID);

                if(studentIndex != -1) {
                    System.out.println(students.get(studentIndex).getCourses().toString());
                }else{
                    System.out.println("student does not exist");
                }

            } catch(InputMismatchException e){
                System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
            }

    }

        //used similar method as in other project jsut to print all data to files. one file for courses the other for
        //students
        public static void printToFile(ArrayList<Student> students, ArrayList<Course> courses){
            try (PrintWriter writer = new PrintWriter(new File("src/students.txt"))) {

                for (Student student : students) {
                    writer.println(student.toString());
                }

            } catch (FileNotFoundException e) {
                System.err.println("Error students file not written");
            }
            try (PrintWriter writer = new PrintWriter(new File("src/courses.txt"))) {

                for (Course c : courses) {
                    writer.println(c.toString());
                }

            } catch (FileNotFoundException e) {
                System.err.println("Error courses file not written");
            }


        }

}
