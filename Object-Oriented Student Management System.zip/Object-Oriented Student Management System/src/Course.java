import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class Course {

    private String courseID;
    private String title;
    private ArrayList<Student> students;

    public Course(String courseID, String title,ArrayList<Student> students ){
        this.courseID = courseID;
        this.title = title;
        this.students = students;
    }
    public Course(String courseID, String title){
        this.courseID = courseID;
        this.title = title;
        this.students = new ArrayList<Student>();
    }

    public void addStudent(Student s){
        students.add(s);
    }
    public void addStudent(String name, String dob, String id){
        Student s = new Student(name,dob,id);
        students.add(s);
    }

    public void deleteStudent(String id){
        for(int i = students.size()-1 ; i>=0 ;i--){
            if(students.get(i).getID().equals(id)){
                students.remove(i);
            }
        }
    }
    //may not work
    public void updateStudent(int key,  ArrayList<Course> courses,String name, String dob){
        Student s = students.get(key);
        s.setCourses(courses);
        s.setName(name);
        s.setDOB(dob);
    }

    public String getCourseID(){
        return courseID;
    }
    public String getTitle(){
        return title;
    }
    public void setCourseID(String courseID){
        this.courseID = courseID;
    }
    public void setTitle(String title){
        this.title = title;
    }
    public ArrayList<Student> getStudents(){
        return students;
    }

    //figure out how to write toString() method
    public String toString(){
        String s2 = "CourseID: " + courseID + " Title: " + title +" Students: ";
        String s3 = "";
        for (Student value : students) {
            s3 += value.getName() + " ";
        }

        return s2 + s3;
    }

}
