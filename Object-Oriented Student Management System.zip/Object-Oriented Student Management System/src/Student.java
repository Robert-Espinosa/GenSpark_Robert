import java.util.ArrayList;
import java.util.HashMap;

public class Student {

    private String id;
    private ArrayList<Course> courses;
    private String name;
    private String dob;

    public Student(String id,  ArrayList<Course> courses, String name, String dob){
        this.id = id;
        this.courses = courses;
        this.name = name;
        this.dob = dob;

    }
    public Student(String id, String name, String dob){
        this.id = id;
        this.courses = new  ArrayList<Course>();
        this.name = name;
        this.dob = dob;
    }

    public void addCourse(String courseID, String title){
        Course c = new Course(courseID,title);
        courses.add( c);
    }
    public void addCourse(Course c){
        courses.add(c);
    }

    public void setID(String id){
        this.id = id;
    }
    public void setCourses( ArrayList<Course> courses){
        this.courses = courses;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setDOB(String dob){
        this.dob = dob;
    }

    public String getID(){
        return id;
    }

    public  ArrayList<Course> getCourses(){
        return courses;
    }

    public String getName(){
        return name;
    }
    public String getDob(){
        return dob;
    }

    public void deleteStudent(String id){
        for(int i = courses.size()-1 ; i>=0 ;i--){
            //System.out.println("here outer loop");
            //System.out.println(id);
            if(courses.get(i).getCourseID().equals(id)){
                courses.remove(i);
            }
        }
    }

    public String toString(){
        String s2 = "ID: " + id + " Name: " + name +" DOB: " + dob + " courses: ";
        String s3 = "";
        for (Course value : courses) {
            s3 += value.getTitle() + " ";
        }

        return s2 + s3;
    }


}
