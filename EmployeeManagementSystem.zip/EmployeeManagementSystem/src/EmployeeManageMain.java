import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class EmployeeManageMain {
    public static void main(String[] args) {
        //cleaner print method that is called statically
        printMenu();

        //Initalize our arrays to store Students and Courses, Becasue we need to store somewhere when initalized.
        ArrayList<Person> people = new ArrayList<>();
        ArrayList<Company> companies = new ArrayList<>();

        //Begin our scanner and scan until user enters -1 to quit
        Scanner in = new Scanner(System.in);
        String input;
        while (!(input = in.next()).equals("-1")) {
            //store what the user wants to do in menu
            int result = 0;

            try {
                result = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input Please enter a number from 1-12 or -1 to quit.");
            }
            //Used helper methods described below in order to call each functionallity of the gradebook
            if (result == 1) {
                //works
                addEmployee(in, people);
            } else if (result == 2) {
                //works
                fireEmployee(in, people, companies);
            } else if (result == 3) {
                viewSingleEmployee(in, people);
            } else if (result == 4) {
                editEmployee(in, people);
            } else if (result == 5) {
                createCompany(in, companies);
            } else if (result == 6) {
                deleteCompany(in, companies);
            } else if (result == 7) {
                editCompany(in, companies);
            } else if (result == 8) {
                viewCompany(in, companies);
            } else if(result==9){
                addEmployeeToCompany(in,companies,people);

            }else if(result == 10){
                addBossToCompany(in,companies,people);

            }
            else {
                //tell them they need to enter number 1-12
                System.out.println("Error Number out of bounds, enter number between 1-12\n");
            }
            for(Company P: companies){
                System.out.println(P.toString());
            }
            for(Company P: companies){
                System.out.println(P.toString());
            }
            //printToFile(students,courses);
            printMenu();
        }
    }

    public static void printMenu() {
        //a lot of print statements so decided to seperate it from the main
        System.out.println("Please select from the menu below the operation you want enter digit 1-12");
        System.out.println("1. Add new employee");
        System.out.println("2. Fire employee");
        System.out.println("3. view an employee");
        System.out.println("4. edit an employee");
        System.out.println("----------------------");
        System.out.println("5. make a company");
        System.out.println("6. delete Company");
        System.out.println("7. edit a company");
        System.out.println("8. view a company");
        System.out.println("----------------------");
        System.out.println("9. add employee to a company");
        System.out.println("10. add boss to company");


    }

    public static void addEmployee(Scanner in, ArrayList<Person> people) {
        try {
            System.out.print("Enter employee name: ");
            String name = in.next();
            System.out.print("enter the employee age: ");
            String age = in.next();
            System.out.print("enter the employee DOB ");
            String DOB = in.next();
            System.out.print("enter the employee SSN ");
            int SSN = in.nextInt();
            System.out.print("enter the employee dept");
            String dept = in.next();
            System.out.print("type in work years of experiece");
            int workExpiernece = in.nextInt();
            System.out.print("Enter Y if remote and N if in person");
            String remote = in.next();
            System.out.print("enter your ID ");
            int id = in.nextInt();

            if (remote.equalsIgnoreCase("y")) {
                people.add(new Employee(name, age, DOB, SSN, id, dept, workExpiernece, true));
            } else {
                people.add(new Employee(name, age, DOB, SSN, id, dept, workExpiernece, false));

            }


        } catch (InputMismatchException e) {
            System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
        }
    }

    public static void editEmployee(Scanner in, ArrayList<Person> people) {
        try {
            System.out.print("Enter ID of employee you woule like to edit: ");
            int id = in.nextInt();

            int index = indexByID(people, id);

            if (index != -1) {
                System.out.print("Enter new name: ");
                String name = in.next();
                System.out.print("enter new age: ");
                String age = in.next();
                System.out.print("enter new DOB ");
                String DOB = in.next();
                System.out.print("enter new SSN ");
                int SSN = in.nextInt();
                System.out.print("enter new dept");
                String dept = in.next();
                System.out.print("type in work years of experiece");
                int workExpiernece = in.nextInt();
                System.out.print("Enter Y if remote and N if in person");
                String remote = in.next();
                System.out.print("enter your ID ");
                int newId = in.nextInt();

                people.get(index).setAge(age);
                people.get(index).setDOB(DOB);
                people.get(index).setName(name);
                //people.get(index).setSSN(name);


                for (Person p : people) {
                    System.out.println(p.toString());
                }


            } else {
                System.out.println("there is no student with that ID");
            }


        } catch (InputMismatchException e) {
            System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
        }
    }

    public static int indexByID(ArrayList<Person> people, int id) {
        for (int i = 0; i < people.size(); i++) {
            if (people.get(i).getId() == id) {
                return i;
            }
        }
        return -1;
    }

    //goes through our array of courses and finds the index of course based on id
    //again more so a helper method for the functions below
    public static int indexOfCompany(ArrayList<Company> companies, String companyName) {
        for (int i = 0; i < companies.size(); i++) {
            if (companies.get(i).getName().equals(companyName)) {
                return i;
            }
        }
        return -1;
    }

    public static void fireEmployee(Scanner in, ArrayList<Person> people, ArrayList<Company> companies) {
        System.out.print("Enter employee ID to fire ");
        int ID = in.nextInt();
        int index = indexByID(people, ID);

        if (index != -1) {
            people.remove(index);
        } else {
            System.out.println("employee not found");

        }

        System.out.println(index);
    }

    public static void viewSingleEmployee(Scanner in, ArrayList<Person> people) {
        try {
            System.out.println("Please enter the id of the employee you want to find");
            int id = in.nextInt();
            int index = indexByID(people, id);

            if (index != -1) {
                System.out.println(people.get(index).toString());
            } else {
                System.out.println("there is no student with that ID");
            }


        } catch (InputMismatchException e) {
            System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
        }


    }

    public static void createCompany(Scanner in, ArrayList<Company> companies) {
        try {
            System.out.println("Please enter the name of company");
            String name = in.next();
            System.out.println("Please enter the location of company");
            String location = in.next();

            Company c = new Company(name, location);

            companies.add(c);


        } catch (InputMismatchException e) {
            System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
        }


    }

    public static void deleteCompany(Scanner in, ArrayList<Company> companies) {
        System.out.println("Please enter the name of company to delete");
        String name = in.next();

        int index = indexOfCompany(companies, name);

        if (index != -1) {
            companies.remove(index);
        } else {
            System.out.println("Company not found");
        }

    }

    public static void editCompany(Scanner in, ArrayList<Company> companies) {
        try {
            System.out.println("Please enter the name of company to edit");
            String name = in.next();


            System.out.println("Please enter new name");
            String newName = in.next();
            System.out.println("Please enter new location");
            String newLocation = in.next();

            int index = indexOfCompany(companies, name);

            if (index != -1) {
                companies.get(index).setName(newName);
                companies.get(index).setLocation(newLocation);
            } else {
                System.out.println("there is no comapny with that name");
            }


        } catch (InputMismatchException e) {
            System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
        }

    }

    public static void viewCompany(Scanner in, ArrayList<Company> companies) {
        try {
            System.out.println("Please enter the name of company to view");
            String name = in.next();


            int index = indexOfCompany(companies, name);

            if (index != -1) {
                System.out.println(companies.get(index).toString());
            } else {
                System.out.println("company does not exist");
            }


        } catch (InputMismatchException e) {
            System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
        }

    }

    public static void addEmployeeToCompany(Scanner in, ArrayList<Company> companies,ArrayList<Person> employees) {
        try {
            System.out.println("Please enter the id of employee to add");
            int id = in.nextInt();
            System.out.println("Please enter the name of company");
            String company = in.next();


            int index = indexOfCompany(companies, company);
            int indexID = indexByID(employees, id);

            if (index != -1 && indexID!=-1) {
                companies.get(index).addEmployee(employees.get(indexID));
            } else {
                System.out.println("company does not exist");
            }


        } catch (InputMismatchException e) {
            System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
        }

    }

    public static void addBossToCompany(Scanner in, ArrayList<Company> companies,ArrayList<Person> people) {
        try {
            System.out.println("Please enter the name of company");
            String company = in.next();

            int index = indexOfCompany(companies, company);


            System.out.print("Enter Bosses Name: ");
            String name = in.next();
            System.out.print("enter the Bosses age: ");
            String age = in.next();
            System.out.print("enter the Bosses DOB ");
            String DOB = in.next();
            System.out.print("enter the Bosses SSN ");
            int SSN = in.nextInt();
            System.out.print("enter the Bosses ID ");
            int id = in.nextInt();
            System.out.print("enter the Bosses dept");
            String dept = in.next();
            System.out.println("type y is boss is hiring or n if not");
            String isHiring = in.next();
            Boss B;
            if (isHiring.equalsIgnoreCase("y")) {
                 B = new Boss(name,age,DOB,SSN,id,true);
                people.add(B);
            } else {
                 B = new Boss(name,age,DOB,SSN,id,Boolean.FALSE);
                people.add(new Boss(name,age,DOB,SSN,id,false));

            }

            if(index != -1){
                companies.get(index).addBoss(B);
            }else{
                System.out.println("company does not exist");
            }

        } catch (InputMismatchException e) {
            System.out.println("please enter an valid Integer, String, integer, and double to add student\n");
        }

    }
}

