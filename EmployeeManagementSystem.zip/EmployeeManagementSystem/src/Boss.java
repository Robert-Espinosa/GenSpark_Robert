public class Boss extends Person {
    private String dept;
    private boolean isHiring;

    public Boss(){
        super("","50","",1020302,0);
    }
    public Boss(String dept, boolean isHiring, int id) {
        super("","50","",1020302,id);
        this.dept = dept;
        this.isHiring = isHiring;
    }
    public Boss(String name, String age, String DOB, int SSN,int id, Boolean isHiring ){
        super(name,age,DOB,SSN,id);
        this.isHiring = isHiring;
    }
    public boolean isHiring() {
        return isHiring;
    }
    public void setHiring(boolean hiring) {
        isHiring = hiring;
    }
    public String getDept() {
        return dept;
    }
    public void setDept(String dept) {
        this.dept = dept;
    }

    @Override
    public String toString() {
        return "Boss{ name:" + getName()+
                " dept='" + dept + '\'' +
                ", isHiring=" + isHiring +
                '}';
    }
}