import java.util.ArrayList;
public class Company {

    private String name;
    private ArrayList<Employee> employees;
    private Boss boss;
    private String location;

    public Company(String name, Boss boss, String location) {
        this.name = name;
        this.boss = boss;
        this.location = location;
        this.employees = new ArrayList<>();

    }
    public Company(String name,String location) {
        this.name = name;
        this.location = location;
        this.employees = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void addEmployee(Person E) {
        this.employees.add((Employee) E);

    }
    public void addBoss(Person E) {
        this.boss = (Boss) E;
    }


    public ArrayList<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(ArrayList<Employee> employees) {
        this.employees = employees;
    }

    public Boss getBoss() {
        return boss;
    }

    public void setBoss(Boss boss) {
        this.boss = boss;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "Company{" +
                "name='" + name + '\'' +
                ", employees=" + employees +
                ", boss=" + boss +
                ", location='" + location + '\'' +
                '}';
    }
}
