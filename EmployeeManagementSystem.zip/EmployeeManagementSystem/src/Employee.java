public class Employee extends Person{
    private String DEPT;
    private int workExperience;
    private boolean isRemote;

    public Employee(String name, String age, String DOB, int SSN,int id ,String DEPT, int workExperience, boolean isRemote){
        super(name,age,DOB,SSN,id);
        this.DEPT = DEPT;
        this.workExperience = workExperience;
        this.isRemote = isRemote;
    }

    public String getDEPT() {
        return DEPT;
    }

    public void setDEPT(String DEPT) {
        this.DEPT = DEPT;
    }

    public int getWorkExperience() {
        return workExperience;
    }

    public void setWorkExperience(int workExperience) {
        this.workExperience = workExperience;
    }

    public boolean isIsRemote() {
        return isRemote;
    }

    public void setIsRemote(boolean isRemote) {
        this.isRemote = isRemote;
    }

    @Override
    public String toString() {

        return "Employee{" +
                "name: " + getName() +" ID: "
                + getId()+" "+
                "DEPT='" + DEPT + '\'' +
                ", workExperience=" + workExperience +
                ", isRemote=" + isRemote +
                '}';
    }
}
