public class Person {
    private String Name;
    private String age;
    private String DOB;
    private int SSN;
    private int id;

    public Person(String Name, String age, String DOB, int SSN, int id) {
        this.Name = Name;
        this.age = age;
        this.DOB = DOB;
        this.SSN = SSN;
        this.id = id;
    }
    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id  = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public int getSSN() {
        return SSN;
    }

    public void setSSN(int SSN) {
        this.SSN = SSN;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }
    @Override
    public String toString() {
        return "Person{" +
                "Name='" + Name + '\'' +
                ", age=" + age +
                ", DOB='" + DOB + '\'' +
                ", SSN=" + SSN +
                '}';
    }

}
